
package net.mcreator.christmas_by_artemon.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.Item;

import net.mcreator.christmas_by_artemon.itemgroup.ChristmasItemGroup;
import net.mcreator.christmas_by_artemon.ChristmasByArtemonModElements;

@ChristmasByArtemonModElements.ModElement.Tag
public class FrankSinatraJingleBellsItem extends ChristmasByArtemonModElements.ModElement {
	@ObjectHolder("christmas_by_artemon:frank_sinatra_jingle_bells")
	public static final Item block = null;
	public FrankSinatraJingleBellsItem(ChristmasByArtemonModElements instance) {
		super(instance, 3);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, ChristmasByArtemonModElements.sounds.get(new ResourceLocation("christmas_by_artemon:jingle_bells")),
					new Item.Properties().group(ChristmasItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("frank_sinatra_jingle_bells");
		}
	}
}
