
package net.mcreator.christmas_by_artemon.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.christmas_by_artemon.itemgroup.ChristmasItemGroup;
import net.mcreator.christmas_by_artemon.ChristmasByArtemonModElements;

import java.util.List;

@ChristmasByArtemonModElements.ModElement.Tag
public class CandyCaneShowelItem extends ChristmasByArtemonModElements.ModElement {
	@ObjectHolder("christmas_by_artemon:candy_cane_showel")
	public static final Item block = null;
	public CandyCaneShowelItem(ChristmasByArtemonModElements instance) {
		super(instance, 12);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ShovelItem(new IItemTier() {
			public int getMaxUses() {
				return 128;
			}

			public float getEfficiency() {
				return 4f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 4;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(CandyCaneItem.block));
			}
		}, 1, -3f, new Item.Properties().group(ChristmasItemGroup.tab)) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("YAY! Time to get sand!"));
			}
		}.setRegistryName("candy_cane_showel"));
	}
}
