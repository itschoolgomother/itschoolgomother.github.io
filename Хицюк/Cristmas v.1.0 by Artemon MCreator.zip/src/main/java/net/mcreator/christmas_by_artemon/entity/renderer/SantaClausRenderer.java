package net.mcreator.christmas_by_artemon.entity.renderer;

import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.MobRenderer;

import net.mcreator.christmas_by_artemon.entity.SantaClausEntity;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class SantaClausRenderer {
	public static class ModelRegisterHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public void registerModels(ModelRegistryEvent event) {
			RenderingRegistry.registerEntityRenderingHandler(SantaClausEntity.entity, renderManager -> {
				return new MobRenderer(renderManager, new Modelcustom_model(), 0.5f) {
					@Override
					public ResourceLocation getEntityTexture(Entity entity) {
						return new ResourceLocation("christmas_by_artemon:textures/5b3dd14ff01bef6b.png");
					}
				};
			});
		}
	}

	// Made with Blockbench 4.0.4
	// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
	// Paste this class into your mod and generate all required imports
	public static class Modelcustom_model extends EntityModel<Entity> {
		private final ModelRenderer leftleg;
		private final ModelRenderer leftleg_r1;
		private final ModelRenderer Legs;
		private final ModelRenderer Legs_r1;
		private final ModelRenderer torse;
		private final ModelRenderer torse_r1;
		private final ModelRenderer arms;
		private final ModelRenderer arms_r1;
		private final ModelRenderer leftarm;
		private final ModelRenderer leftarm_r1;
		private final ModelRenderer hand;
		private final ModelRenderer hand_r1;
		public Modelcustom_model() {
			textureWidth = 64;
			textureHeight = 64;
			leftleg = new ModelRenderer(this);
			leftleg.setRotationPoint(-2.0F, 12.0F, 0.0F);
			setRotationAngle(leftleg, 0.0F, 1.5708F, 0.0F);
			leftleg_r1 = new ModelRenderer(this);
			leftleg_r1.setRotationPoint(0.0F, 0.0F, 1.0F);
			leftleg.addChild(leftleg_r1);
			setRotationAngle(leftleg_r1, 0.0F, -1.5708F, 0.0F);
			leftleg_r1.setTextureOffset(0, 16).addBox(-3.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, 0.0F, false);
			Legs = new ModelRenderer(this);
			Legs.setRotationPoint(0.0F, 24.0F, 0.0F);
			setRotationAngle(Legs, -3.1416F, 1.5708F, 3.1416F);
			Legs_r1 = new ModelRenderer(this);
			Legs_r1.setRotationPoint(0.0F, -12.0F, 0.0F);
			Legs.addChild(Legs_r1);
			setRotationAngle(Legs_r1, 0.0F, -1.5708F, 0.0F);
			Legs_r1.setTextureOffset(16, 48).addBox(0.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, 0.0F, false);
			torse = new ModelRenderer(this);
			torse.setRotationPoint(0.0F, 2.0F, 0.0F);
			Legs.addChild(torse);
			torse_r1 = new ModelRenderer(this);
			torse_r1.setRotationPoint(0.0F, -6.0F, 0.0F);
			torse.addChild(torse_r1);
			setRotationAngle(torse_r1, 0.0F, -1.5708F, 0.0F);
			torse_r1.setTextureOffset(16, 16).addBox(-4.0F, -20.0F, -2.0F, 8.0F, 12.0F, 4.0F, 0.0F, false);
			arms = new ModelRenderer(this);
			arms.setRotationPoint(0.0F, 0.0F, 0.0F);
			torse.addChild(arms);
			arms_r1 = new ModelRenderer(this);
			arms_r1.setRotationPoint(0.0F, -26.0F, -4.0F);
			arms.addChild(arms_r1);
			setRotationAngle(arms_r1, 0.0F, 1.5708F, 0.0F);
			arms_r1.setTextureOffset(40, 16).addBox(0.0F, 0.0F, -2.0F, 3.0F, 12.0F, 4.0F, 0.0F, false);
			leftarm = new ModelRenderer(this);
			leftarm.setRotationPoint(0.0F, -16.0F, 3.0F);
			arms.addChild(leftarm);
			leftarm_r1 = new ModelRenderer(this);
			leftarm_r1.setRotationPoint(0.0F, -10.0F, 1.0F);
			leftarm.addChild(leftarm_r1);
			setRotationAngle(leftarm_r1, 0.0F, 1.5708F, 0.0F);
			leftarm_r1.setTextureOffset(32, 48).addBox(-3.0F, 0.0F, -2.0F, 3.0F, 12.0F, 4.0F, 0.0F, false);
			hand = new ModelRenderer(this);
			hand.setRotationPoint(0.0F, -21.0F, 0.0F);
			arms.addChild(hand);
			hand_r1 = new ModelRenderer(this);
			hand_r1.setRotationPoint(0.0F, -5.0F, 0.0F);
			hand.addChild(hand_r1);
			setRotationAngle(hand_r1, 0.0F, -1.5708F, 0.0F);
			hand_r1.setTextureOffset(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, 0.0F, false);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			leftleg.render(matrixStack, buffer, packedLight, packedOverlay);
			Legs.render(matrixStack, buffer, packedLight, packedOverlay);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
			this.leftleg_r1.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
			this.leftarm_r1.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
			this.Legs_r1.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
			this.arms_r1.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
			this.hand.rotateAngleY = f3 / (180F / (float) Math.PI);
			this.hand.rotateAngleX = f4 / (180F / (float) Math.PI);
		}
	}
}
