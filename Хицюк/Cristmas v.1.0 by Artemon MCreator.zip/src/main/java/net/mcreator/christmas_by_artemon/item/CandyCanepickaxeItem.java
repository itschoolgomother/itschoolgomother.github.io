
package net.mcreator.christmas_by_artemon.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.block.BlockState;

import net.mcreator.christmas_by_artemon.procedures.PickaxefsProcedure;
import net.mcreator.christmas_by_artemon.itemgroup.ChristmasItemGroup;
import net.mcreator.christmas_by_artemon.ChristmasByArtemonModElements;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

@ChristmasByArtemonModElements.ModElement.Tag
public class CandyCanepickaxeItem extends ChristmasByArtemonModElements.ModElement {
	@ObjectHolder("christmas_by_artemon:candy_canepickaxe")
	public static final Item block = null;
	public CandyCanepickaxeItem(ChristmasByArtemonModElements instance) {
		super(instance, 8);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 100000;
			}

			public float getEfficiency() {
				return 4f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 4;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(CandyCaneItem.block));
			}
		}, 1, -3f, new Item.Properties().group(ChristmasItemGroup.tab)) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("Yummy Pickaxe! I want eat it!"));
			}

			@Override
			public boolean onBlockDestroyed(ItemStack itemstack, World world, BlockState blockstate, BlockPos pos, LivingEntity entity) {
				boolean retval = super.onBlockDestroyed(itemstack, world, blockstate, pos, entity);
				int x = pos.getX();
				int y = pos.getY();
				int z = pos.getZ();
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					$_dependencies.put("x", x);
					$_dependencies.put("y", y);
					$_dependencies.put("z", z);
					$_dependencies.put("world", world);
					PickaxefsProcedure.executeProcedure($_dependencies);
				}
				return retval;
			}
		}.setRegistryName("candy_canepickaxe"));
	}
}
